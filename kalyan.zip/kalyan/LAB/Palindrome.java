import java.util.*;
class Palindrome
{
	 public static void main(String[] args)
	 {
	 	Scanner sc=new Scanner(System.in);
	 	int num;
	 	System.out.print("Enter number to know whether it is palindrome or not: ");
	 	num=sc.nextInt();
	 	int temp=num;
	 	int rem,sum=0;
	 	while(num!=0)
	 	{
	 		rem=num%10;
	 		sum=sum*10+rem;
	 		num/=10;
	 	}
	 	if(sum==temp)
	 	{
	 		System.out.println(sum+" is Palindrome");
	 	}
	 	else
	 		System.out.println(temp+" is not Palindrome");
	 }
}
