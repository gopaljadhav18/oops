class Lamp
{
	public boolean isOn;
	public String lampType;
	public Lamp(boolean state,String str1)
	{
		this.isOn=state;
		this.lampType=str1;
	}
	public boolean turnOn()
	{
		System.out.println("Previous: "+isOn);
		this.isOn=true;
		return isOn;
	}
	public boolean turnOff()
	{
		System.out.println("Previous: "+isOn);
		this.isOn=false;
		return isOn;
	}
	public static void main(String[] args)
	{
		Lamp obj1=new Lamp(false,"LED");
		Lamp obj2=new Lamp(true,"Halogen");
		Lamp obj3=new Lamp(true,"Philips");
		
		System.out.println(obj1.lampType+":"+obj1.turnOn());
		System.out.println(obj2.lampType+":"+obj2.turnOff());
		System.out.println(obj3.lampType+":"+obj3.turnOff());
		
		System.out.println(obj1.lampType+":"+obj1.turnOff());
		System.out.println(obj2.lampType+":"+obj2.turnOn());
		System.out.println(obj3.lampType+":"+obj3.turnOn());
		
		System.out.println(obj1.lampType+":"+obj3.turnOff());
		System.out.println(obj2.lampType+":"+obj2.turnOn());
		System.out.println(obj3.lampType+":"+obj3.turnOff());
	}
}
