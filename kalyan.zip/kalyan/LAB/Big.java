import java.util.*;
class Big
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int arr[]=new int[5];
		int min=Integer.MAX_VALUE;
		int max=Integer.MIN_VALUE;
		System.out.print("Enter any 5 numbers: ");
		for(int i=0;i<5;i++)
			arr[i]=sc.nextInt();
		for(int i:arr)
		{
			if(min>i)
				min=i;
			if(max<i)
				max=i;
		}
		System.out.println("Minimum: "+min+"\nMaximum: "+max);
	}
}
