import java.util.*;
class Calculator
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 for Addition");
		System.out.println("Enter 2 for Subtraction");
		System.out.println("Enter 3 for Mutilpication");
		System.out.println("Enter 4 for Division");
		System.out.print("ENTER HERE:  ");
		int sct=sc.nextInt();
		while(sct!=-1)
		{
			switch(sct)
			{
				case 1:
				{
					System.out.print("Enter num1: ");
					double num1=sc.nextDouble();
					System.out.print("Enter num2: ");
					double num2=sc.nextDouble();
					System.out.println(num1+num2);
					break;
				}
				case 2:
				{
					System.out.print("Enter num1: ");
					double num1=sc.nextDouble();
					System.out.print("Enter num2: ");
					double num2=sc.nextDouble();
					System.out.println(num1-num2);
					break;
				}
				case 3:
				{
					System.out.print("Enter num1: ");
					double num1=sc.nextDouble();
					System.out.print("Enter num2: ");
					double num2=sc.nextDouble();
					System.out.println(num1*num2);
					break;
				}
				case 4:
				{
					System.out.print("Enter num1: ");
					double num1=sc.nextDouble();
					System.out.print("Enter num2: ");
					double num2=sc.nextDouble();
					System.out.println(num1/num2);
					break;
				}
				default:
				{
					System.out.print("Enter valid Input");
					break;
				}
			}
			System.out.print("If want to continue Enter Opeatarion Digit or to STOP Enter -1: ");
			sct=sc.nextInt();	
		}
	}
}
