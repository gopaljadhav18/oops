import java.util.*;
import java.lang.*;
class quadratic 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		double a,b,c;
		System.out.print("Enter Co-Efficient of x**2: ");
		a=sc.nextDouble();
		System.out.print("Enter Co-Efficient of x: ");
		b=sc.nextDouble();
		System.out.print("Enter Constant term: ");
		c=sc.nextDouble();
		double dscrt=b*b-4*a*c;
		if(dscrt>0)
		{
			double ans1= ((-b)+Math.sqrt(dscrt))/(2*a);
			double ans2= ((-b)-Math.sqrt(dscrt))/(2*a);
			System.out.println("root1: "+ans1+"\n"+"root2: "+ans2);
		}
		else if(dscrt==0)
		{
			double ans= ((-b)+Math.sqrt(dscrt))/(2*a);
			System.out.println("root1: "+ans+"\n"+"root2: "+ans);
		}
		else
		{
			double rt1=(-b/2*a);
			double rt2=Math.sqrt(-1*dscrt)/2*a;
			System.out.printf("root1: %.2f+i%.2f\n",rt1,rt2);
			System.out.printf("root2: %.2f-i%.2f\n",rt1,rt2);
			//System.out.printf("root2: "+rt1+"-i"+rt2);
		}
	}
}
