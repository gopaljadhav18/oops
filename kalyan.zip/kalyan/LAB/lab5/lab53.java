import java.util.*;
interface Vechile
{
	public void getType();
	public void getConsumption();
	public void getCompany();
	public void getModel();
}
class Two_Wheeler implements Vechile
{
	Scanner sc=new Scanner(System.in);
	String type,company,model;
	public Two_Wheeler(String type,String Company,String Model)
	{
		this.type=type;
		this.company=Company;
		this.model=Model;
	}
	public void getType(){System.out.println(this.type);}
	public void getConsumption()
	{
		//And for 2- wheeler is 62km/Ltr(petrol) 82km/ltr(Diesel),72km/ltr(cng).
		System.out.println("Enter Distance Travelled: ");
		float dist=sc.nextInt();
		if(this.type.equals("Petrol")){System.out.println((float) dist/62);}
		else if(this.type.equals("Diesel")){System.out.println((float) dist/82);}
		else if(this.type.equals("cng")){System.out.println((float) dist/72);}
	}
	public void getCompany(){System.out.println(this.company);}
	public void getModel(){System.out.println(this.model);}
}
class Four_Wheeler implements Vechile
{
	Scanner sc=new Scanner(System.in);
	String type,company,model;
	public Four_Wheeler(String type,String Company,String Model)
	{
		this.type=type;
		this.company=Company;
		this.model=Model;
	}
	public void getType(){System.out.println(this.type);}
	public void getConsumption()
	{
		//Mileage for 4-wheeler is 14km/Ltr(petrol), 22km/Ltr(Diesel),18km/kg(CNG)
		System.out.println("Enter Distance Travelled: ");
		float dist=sc.nextInt();
		if(this.type.equals("Petrol")){System.out.println((float) dist/14);}
		else if(this.type.equals("Diesel")){System.out.println((float) dist/22);}
		else if(this.type.equals("cng")){System.out.println((float) dist/18);}
	}
	public void getCompany(){System.out.println(this.company);}
	public void getModel(){System.out.println(this.model);}
}
class lab53
{
	public static void main(String[] args)
	{
		Vechile obj1=new Two_Wheeler("Petrol","TATA","2022");
		Vechile obj2=new Four_Wheeler("Diesel","TATA","2010");
		obj1.getConsumption();
		obj2.getConsumption();
	}
}
