abstract class Employee
{
	public abstract float getAmount();	
}
class HourlyEmployee extends Employee
{
	float amount,worked,total;
	public HourlyEmployee(float amt,float worked,float total)
	{
		this.amount=amt;
		this.worked=worked;
		this.total=total;
	}
	public float getAmount()
	{
		return (this.worked/this.total)*this.amount;
	}
}
class WeeklyEmployee extends Employee
{
	float amount,worked,total;
	public WeeklyEmployee(float amt,float worked,float total)
	{
		this.amount=amt;
		this.worked=worked;
		this.total=total;
	}
	public float getAmount()
	{
		//System.out.println((float)(this.worked/this.total));
		return (this.worked/this.total)*this.amount;
	}
}
class lab52
{
	public static void main(String[] args)
	{
		Employee Hemp=new HourlyEmployee(30000,8,10);
		Employee Wemp=new WeeklyEmployee(50000,7,10);
		System.out.println(Hemp.getAmount());
		System.out.println(Wemp.getAmount());
	}
}
