import java.lang.*;
import java.util.*;
abstract class Shape
{
	public abstract Double getArea();
	public abstract Double getVolume();
}
class Circle extends Shape
{
	Double radius;
	public Circle(Double radius)
	{
		this.radius=radius;
	}
	public Double getArea()
	{
		return Math.PI*this.radius*this.radius;
	}
	public Double getVolume()
	{
		return 2*Math.PI*this.radius;
	}
}
class Square extends Shape
{
	Double side;
	public Square(Double side)
	{
		this.side=side;
	}
	public Double getArea()
	{
		return this.side*this.side;
	}
	public Double getVolume()
	{
		return 4*this.side;
	}
}
class Cube extends Shape
{
	Double side;
	public Cube(Double side)
	{
		this.side=side;
	}
	public Double getArea()
	{
		return 6*this.side;
	}
	public Double getVolume()
	{
		return this.side*this.side*this.side;
	}
}
class Sphere extends Shape
{
	Double radius;
	public Sphere(Double radius)
	{
		this.radius=radius;
	}
	public Double getArea()
	{
		return 4*Math.PI*this.radius*this.radius;
	}
	public Double getVolume()
	{
		return (float)(4/3)*Math.PI*this.radius*this.radius*this.radius;
	}
}
class lab51
{
	public static void main(String[] args)
	{
		Shape obj1=new Circle(4.0);
		Shape obj2=new Square(4.0);
		Shape obj3=new Sphere(4.3);
		Shape obj4=new Cube(5.0);
		System.out.println(obj1.getArea());
		System.out.println(obj2.getArea());
		System.out.println(obj3.getArea());
		System.out.println(obj4.getArea());
	}
}

