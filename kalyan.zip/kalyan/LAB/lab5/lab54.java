interface Fare
{
	public void getFare();
	public void getAminities();
}
class Bus implements Fare
{
	public void getFare()
	{
		
	}
}
