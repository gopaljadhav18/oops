import java.util.*;
import java.lang.*;
public class Circle
{
	private double radius;
	public Circle(double elem)
	{
		radius=elem;
	}
	public double getArea()
	{
		return Math.PI*radius*radius;
	}
	public double getPerimeter()
	{
		return 2*Math.PI*radius;
	}
	public static void main(String[] args)
	{
		Circle obj=new Circle(4);
		System.out.println("Area: "+obj.getArea());
		System.out.println("Perimeter: "+obj.getPerimeter());
		Circle obj1=new Circle(5);
		System.out.println("Area: "+obj1.getArea());
		System.out.println("Perimeter: "+obj1.getPerimeter());
		Circle obj2=new Circle(6);
		System.out.println("Area: "+obj2.getArea());
		System.out.println("Perimeter: "+obj2.getPerimeter());
	}
}

