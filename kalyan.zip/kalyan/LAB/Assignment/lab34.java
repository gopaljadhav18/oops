import java.util.*;

public class lab34
{
   public static void main(String[] args)
   {
      Scanner sc=new Scanner(System.in);
      
      System.out.print("Enter 2 strings : ");
      String str1=sc.next();
      String str2=sc.next();
      
      System.out.println(str1.concat(str2));
   }
}
