import java.util.*;

class Book{

   private String Book_Name,Book_Author;
   private int Book_Count;
   
   public Book(String Book_Name,String Book_Author,int Book_Count)
   {
     this.Book_Name=Book_Name;
     this.Book_Author=Book_Author;
     this.Book_Count=Book_Count;
   }
   
   public String getBook_Name(){
           return Book_Name;
   }
   
   public String getBook_Author(){
           return Book_Author;
   }

   public int getBook_Count(){
           return Book_Count;
   }
   
}

class Customer{

   private String Customer_Name,Customer_Address;
   private int Customer_Id;
   
   public Customer(int Customer_Id,String Customer_Name,String Customer_Address)
   {
     this.Customer_Name=Customer_Name;
     this.Customer_Address=Customer_Address;
     this.Customer_Id=Customer_Id;
   }
   
   public String getCustomer_Name(){
           return Customer_Name;
   }
   
   public String getCustomer_Address(){
           return Customer_Address;
   }

   public int getCustomer_Id(){
           return Customer_Id;
   }
   
}


public class BookStall
{
   public static void main(String args[])
   {
     Scanner sc=new Scanner(System.in);
     
     ArrayList<Book> Books=new ArrayList<>();
     ArrayList<Customer> Customers=new ArrayList();
     
     System.out.println("Choose task:\n1.add new book\n2.cutsomer_buy\n");
     
     int choice=sc.nextInt();
     switch(choice)
     {
       case 1:
              String Book_Name,Book_Author;
              int Book_Count;
              
              System.out.print("Enter Book_Name: ");
              Book_Name=sc.next();
              
              System.out.print("Enter Book_Author: ");
              Book_Author=sc.next();
              
              System.out.print("Enter Book_Count: ");
              Book_Count=sc.nextInt();
              
              Books.add(new Book(Book_Name,Book_Author,Book_Count));
              
       case 2:
              String Customer_Name,Customer_Address;
              int Customer_Id;
              
              System.out.print("Enter Customer_Id: ");
              Customer_Id=sc.nextInt();
              
              System.out.print("Enter Customer_Name: ");
              Customer_Name=sc.next();
              
              System.out.print("Enter Customer_Address: ");
              Customer_Address=sc.next();
              
              
              Customers.add(new Customer(Customer_Id,Customer_Name,Customer_Address));
    
              System.out.print("Book he buys: ");
              String book=sc.next();
              
              
              
              System.out.println("Book_Name: "+book);
              System.out.println("Remaining count: "+getCount());
              
      }
      
   }
}    
     
     
