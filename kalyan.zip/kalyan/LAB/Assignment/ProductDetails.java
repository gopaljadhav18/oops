import java.util.*;

class Product
{
    private String p_name;
    private int p_quant;
    private double p_price;

    public Product(String p_name, int p_quant, double p_price)
    {
        this.p_name = p_name;
        this.p_quant = p_quant;
        this.p_price = p_price;
    }

    public String getName() {
        return p_name;
    }

    public double getPrice() {
        return p_price;
    }
}



public class ProductDetails 
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        
        Map<Integer, Product> productMap = new HashMap<>();
        Map<Integer,Integer> mp=new HashMap<>();

        System.out.print("Enter the no.of products :");
        int n=sc.nextInt();
        
        System.out.println("Enter their Details:");
        while(n-->0)
        {
          int p_id=sc.nextInt();
          
          String p_name=sc.next();
          int p_quant=sc.nextInt();
          double p_price=sc.nextDouble();
          
          productMap.put(p_id, new Product(p_name,p_quant,p_price));
          
       }

        System.out.print("Enter no.of prducts sold: ");
        int m= sc.nextInt();

        System.out.println("Enter their prod.Id's & quant.sold : ");
        while(m-->0)
        {
           int id=sc.nextInt();
           int quant=sc.nextInt();
           
           mp.put(id,quant);
        }
        
         System.out.println("p_name         rtl_price    total rtl_value");
         for(Map.Entry<Integer,Integer> i : mp.entrySet())
         {
           if( productMap.containsKey(i.getKey()) )
           {
             Product req_product = productMap.get(i.getKey());
             
             int quant=i.getValue();
             double total_price=req_product.getPrice()*quant;
             System.out.println(req_product.getName()+"         "+req_product.getPrice()+"         "+total_price);
          }
          else
            System.out.println("Product not found!!");
         }
         
    }
}

