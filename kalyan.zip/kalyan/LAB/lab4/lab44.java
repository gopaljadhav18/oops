import java.util.*;
class Account
{
	//Bank_Name, Branch_Name, Acct_Name, Acct_No, Acct_Bal,Acct_Address
	String Bank_Name;
	String Acct_No;
	String Branch_Name;
	int Acct_Bal;
	String Acct_Address;
	public Account(String Bank_Name,String Acct_No,String Branch_Name,int Acct_Bal,String Acct_Address)
	{
		this.Bank_Name=Bank_Name;
		this.Acct_No=Acct_No;
		this.Branch_Name=Branch_Name;
		this.Acct_Bal=Acct_Bal;
		this.Acct_Address=Acct_Address;
	}
	public void credit(int amount)
	{
		this.Acct_Bal+=amount;
		System.out.println(amount+" Credited Succesfully");
	}
	public void dedit(int amount)
	{
		if(this.Acct_Bal-amount>1000)
		{
			this.Acct_Bal=-amount;
			System.out.println(amount+" Debited Succesfully");
		}
		else
		{
			System.out.println("Insufficient Funds");
		}
	}
	public void getBalance()
	{
		System.out.println(this.Acct_Bal);
	}
	public boolean exit()
	{
		return false;
	}
}
class Bank
{
	private Map<String,Map<String,Integer>>accountDetails=new HashMap<>();
	private Map<String,Inetger>BasarAccounts=new Hashmap<>();
	BasarAccounts.put("111000",1500);
	BasarAccounts.put("222000",1200);
	BasarAccounts.put("133000",1300);
	BasarAccounts.put("100300",1030);
	BasarAccounts.put("122334",1300);
	private Map<String,Inetger>NizamabadAccounts=new Hashmap<>();
	BasarAccounts.put("222333",1100);
	BasarAccounts.put("111222",2000);
	BasarAccounts.put("777888",1300);
	BasarAccounts.put("999888",1220);
	BasarAccounts.put("556655",1300);
	accountDetails.put("Basar",BasarAccounts);
	accountDetails.put("Nizamabad",NizamabadAccounts);
	private static check(String Branch,String Account)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter BranchName: ");
		String Branch_name=sc.nextLine();
		System.out.println("Enter AccountNo: ");
		String act_no=sc.nextLine();
		if(accountDetails.containsKey(Branch_name) && accountDetails.containsKey(Branch_name).containsKey(act_no))
		{
			System.out.println("Successfully Logged in");
			int amt=accountDetails.get(Branch_name).get(act_no)
			return new Account("SBI",act_no,Branch_name,amt,Branch_name);
		}
		else
			return null;
	}
}
class lab44
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			obj=new Bank();
			if(obj!=null)
			{
				System.out.println("Enter 1 to Credit\n2 to Debit\n3 to Balance\n4 to exit")
				int flag=sc.nextInt();
				while(flag!=4)
				{
					if(flag==1)
					{
						System.out.println("Enter Amount to Credit: ");
						int amt=sc.nextInt();
						obj.credit(amt);
					}
					else if(flag==2)
					{
						System.out.println("Enter Amount to Debit: ");
						int amt=sc.nextInt();
						obj.debit(amt);
					}
					else if(flag==3)
					{
						obj.getBalance();
					}
					System.out.println("Enter 1 to Credit\n2 to Debit\n3 to Balance\n4 to exit")
					int flag=sc.nextInt();
				}
			}
			else
			{
				System.out.pritln("Invalid Credentials");
			}
			System.out.println("Enter -1 to exit or 0 to continue: ");
			int brk=sc.nextInt();			
			if(brk==-1)
				break;
		}
	}
}
