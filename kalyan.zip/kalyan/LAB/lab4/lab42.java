import java.util.*;
class Person
{
	String Name;
	String Address;
	public Person(String name,String Add)
	{
		this.Name=name;
		this.Address=Add;		
	}
	public void getName()
	{
		System.out.println(this.Name);
				
	}
	public void getAddress()
	{
		System.out.println(this.Address);
				
	}
	public void setAddress(String add)
	{
		//System.out.println(this.Address);
		this.Address=add;		
	}
}
class Student extends Person
{
	String numcourses;
	List<String>Course=new ArrayList<>();
	List<Double>Grades=new ArrayList<>();
	public Student(String name,String Add)
	{
		super(name,Add);
		this.Name=name;
		this.Address=Add;		
	}
	public void addCourse(String crs,Double grade)
	{
		if(Course.size()<30)
		{
			this.Course.add(crs);
			this.Grades.add(grade);	
			System.out.println(crs+"added Succesfully");
		}
		else
		{
			System.out.println("Already Took Maximum Course");
		}
	}
	public void AverageGrade()
	{
		int sum=0;
		for(int i=0;i<this.Course.size();i++)
		{	
			sum+=this.Grades.get(i);
		}
		System.out.println(sum/this.Grades.size());
	}
}
class Teacher extends Person
{
	List<String>Course=new ArrayList<>();
	public Teacher(String name,String Add)
	{
		super(name,Add);
		this.Name=name;
		this.Address=Add;
	}
	public  void AddCourse(String name)
	{
		if(Course.size()<5)
		{
			this.Course.add(name);
			System.out.println(name+"added Succesfully");
		}
		else
		{
			System.out.println("Already Maximum Course Teaching");
		}
	}
	public void RemoveCourse(String name)
	{
		if(Course.size()>0)
		{
			this.Course.remove(name);
			System.out.println(name+"removed Succesfully");
		}
		else
			System.out.println("No Courses to remove");
	}
	
}
class lab42
{
	public static void main(String[] args)
	{
		Student stu=new Student("Kalyan","Karimnagar");
		stu.addCourse("DSA",95.0);
		Teacher tch=new Teacher("XXXX","Karimnagar");
		tch.AddCourse("DSA");
		tch.AddCourse("DAA");	
		tch.AddCourse("DBMS");
		tch.RemoveCourse("DAA");		
	}
}
