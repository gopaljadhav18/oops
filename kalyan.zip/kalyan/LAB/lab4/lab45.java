import java.util.*;
class lab45
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Scanner num=new Scanner(System.in);
		System.out.println("Enter Product: ");
		String product=sc.nextLine();
		System.out.println("Enter Quantity: ");
		int qty=num.nextInt();
		System.out.println("Enter price at Amazon: ");
		int amt_amzn=num.nextInt();
		double flag1=qty*amt_amzn;
		System.out.println("Enter price at Flipkart:");
		int amt_flip=num.nextInt();
		double flag2=qty*amt_flip;
		System.out.println("Are you an HDFC Holder");
		String hdfc=sc.nextLine();
		System.out.println("Are you an RGUKTian: ");
		String rgukt=sc.nextLine();
		if(hdfc.equalsIgnoreCase("Yes"))
		{
			if(flag1>50000)
			{
				flag1=flag1-flag1*(0.15+0.1);	
			}
			else
			{	
				flag1=flag1-flag1*(0.1);		
			}
		}
		else
		{
			if(flag1>50000)
				flag1=flag1-flag1*(0.15);
		}
		if(rgukt.equalsIgnoreCase("Yes"))
		{
			if(flag2>30000)
			{
				flag2=flag2-flag2*(0.3+0.05);
			}
			else
				flag2=flag2-flag2*(0.05);
		}
		else
		{
			if(flag2>30000)
				flag2=flag2-flag2*(0.05);
		}
		if(flag1<flag2)
		{
			System.out.println("Buy at Amazon");
		}
		else
		{
			System.out.println("Buy at Flipkart");
		}
	}
}
458827487084
