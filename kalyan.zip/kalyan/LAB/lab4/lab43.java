class Monster
{
	public void attack()
	{
		System.out.println("Super_Monster");
	}
}
class FireMonster extends Monster
{
	public void attack()
	{
		System.out.println("FireMonster");
	}
}
class WaterMonster extends Monster
{
	public void attack()
	{
		System.out.println("WaterMonster");
	}
}
class StoneMonster extends Monster
{
	public void attack()
	{
		System.out.println("StoneMonster");
	}
}
class lab43
{
	public static void main(String[] args)
	{
		Monster fire=new FireMonster();
		Monster water=new WaterMonster();
		Monster stone=new StoneMonster();
		fire.attack();
		water.attack();
		stone.attack();
	}
}
