import java.util.*;
import java.lang.*;
class Shape
{
	
	public double getArea()
	{
		System.out.println("Iam at Shape");	
		return 0;
	};
	public double getPerimeter()
	{
		return 0;
	};
}
class Circle extends Shape
{
	int radius;
	public Circle(int radius)
	{
		this.radius=radius;
	}
	public double getArea()
	{
		return 2*Math.PI*this.radius;
	}
	public double getPerimeter()
	{
		return Math.PI*this.radius*this.radius;
	}
}
class Square extends Shape
{
	int side;
	public Square(int radius)
	{
		this.side=side;
	}
	public double getArea()
	{
		super.getArea();
		return this.side*this.side;
	}
	public double getPerimeter()
	{
		return 4*this.side;
	}
}
class Rectangle extends Shape
{
	int length,breadth;
	public Rectangle(int length,int breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	public double getArea()
	{
		return this.length*this.breadth;
	}
	public double getPerimeter()
	{
		return 2*(this.length+this.breadth);
	}
}
class lab41
{
	public static void main(String[] args)
	{
		Circle cir=new Circle(5);
		Square sqr=new Square(6);
		Rectangle rect=new Rectangle(3,4);
		System.out.println(cir.getArea());
		System.out.println(cir.getPerimeter());
		System.out.println(sqr.getArea());
		System.out.println(sqr.getPerimeter());
		System.out.println(rect.getArea());
		System.out.println(rect.getPerimeter());
	}
	
}
