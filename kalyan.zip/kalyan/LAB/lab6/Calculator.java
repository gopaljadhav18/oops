package pack1;
public interface Calculator
{
	public int getAddition();
	public int getSubtraction();
	public int getMultiplication();
	public float getDivision();
}
