package pack3;
public class Square
{
	int side;
	public Square(int side)
	{
		this.side=side;
	}
	public int getArea()
	{
		return this.side*this.side;
	}
	public int getPerimeter()
	{
		return this.side*4;
	}
}
