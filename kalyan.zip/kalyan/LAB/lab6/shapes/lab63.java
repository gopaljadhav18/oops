import pack3.Square;
import pack3.Circle;
import pack3.Triangle;
public class lab63
{
	public static void main(String[] args)
	{
		Square sq=new Square(5);
		Circle cr=new Circle(3);
		Triangle tr=new Triangle(2,3,4);
		System.out.println("Square Area: "+sq.getArea());
		System.out.println("Square Perimeter: "+sq.getPerimeter());
		System.out.println("Circle Area: "+cr.getArea());
		System.out.println("Circle Perimeter: "+cr.getPerimeter());
		System.out.println("Triangle Area: "+tr.getArea(6,4));
		System.out.println("Triangle Perimeter: "+tr.getPerimeter());
	}
}
