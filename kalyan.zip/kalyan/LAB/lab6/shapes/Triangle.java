package pack3;
import java.lang.*;
public class Triangle
{
	int side1,side2,side3;
	public Triangle(int side1,int side2,int side3)
	{
		this.side1=side1;
		this.side2=side2;
		this.side3=side3;
	}
	public float getArea(int base,int height)
	{
		return (float)base*height/2;	
	}
	public int getPerimeter()
	{
		return (this.side1+this.side2+this.side3);
	}
}
