package pack3;
import java.lang.*;
public class Circle
{
	int radius;
	public Circle(int side)
	{
		this.radius=side;
	}
	public Double getArea()
	{
		return Math.PI*this.radius*this.radius;
	}
	public Double getPerimeter()
	{
		return 2*Math.PI*this.radius;
	}
}
