import pack1.Calculator;
class operations implements Calculator
{
	int num1,num2;
	public operations(int a,int b)
	{
		this.num1=a;
		this.num2=b;
	}
	public int getAddition()
	{
		return this.num1+this.num2;
	}
	public int getSubtraction()
	{
		return this.num1-this.num2;
	}
	public int getMultiplication()
	{
		return this.num1*this.num2;
	}
	public float getDivision()
	{
		return (float)this.num1/this.num2;
	}
}
public class lab61_1
{
	public static void main(String[] args)
	{
		Calculator calci=new operations(3,4);
		System.out.println(calci.getAddition());
		System.out.println(calci.getSubtraction());
		System.out.println(calci.getMultiplication());
		System.out.println(calci.getDivision());
	}
}	
