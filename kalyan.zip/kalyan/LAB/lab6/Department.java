package pack2;
public interface  Department
{
	public void display_subjects();
}
