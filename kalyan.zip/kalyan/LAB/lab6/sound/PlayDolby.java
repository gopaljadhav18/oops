package pack4;
import pack4.Sounds;
public class PlayDolby implements Sounds
{
	public void playDolby(String text)
	{
		System.out.println("Playing "+text);
	}
}
