package pack4;
public interface Sounds
{
	public void playDolby(String text);
}
