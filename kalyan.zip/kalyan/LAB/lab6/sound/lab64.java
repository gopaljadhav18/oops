import pack4.PlayDolby;
import pack4.Sounds;
class lab64
{
	public static void main(String[] args)
	{
		PlayDolby song1=new PlayDolby();
		song1.playDolby("JaiSriRam");
                song1.playDolby("JaiHanuman");

	}
}
