package pack6;
import java.util.*;
public class M_Seva
{
	List<String> symptoms=new ArrayList<>();
	Map<String,List<String>> mapp=new HashMap<>();
	public M_Seva(String... symp)
	{
		for(int i=0;i<symp.length;i++)
		{
			this.symptoms.add(symp[i]);
		}
		List<String> stom=new ArrayList<>();
		stom.add("AP");
		stom.add("A");
		stom.add("BC");
		stom.add("PC");
		List<String> vomit=new ArrayList<>();
		vomit.add("AP");
		vomit.add("A");
		vomit.add("BC");
		vomit.add("PC");
		List<String> loweye=new ArrayList<>();
		loweye.add("AP");
		loweye.add("A");
		loweye.add("BC");
		loweye.add("PC");
		List<String> fever=new ArrayList<>();
		fever.add("AP");
		fever.add("A");
		fever.add("PC");
		List<String> muscle=new ArrayList<>();
		muscle.add("AP");
		List<String> fatigue=new ArrayList<>();
		fatigue.add("A");
		fatigue.add("PC");
		List<String> skin=new ArrayList<>();
		skin.add("BC");
		List<String> bp=new ArrayList<>();
		bp.add("BC");
		mapp.put("stomachpain",stom);
		mapp.put("vomitting",vomit);
		mapp.put("loweyesight",loweye);
		mapp.put("fever",fever);
		mapp.put("muscleache",muscle);
		mapp.put("fatigue",fatigue);
		mapp.put("skinallergy",skin);
		mapp.put("lowbp",bp);
	}
	public void getDisease()
	{
		Set<String> res=new HashSet<>();
		//Set<String> temp=new HashSet<>();
		for(int i=0;i<this.symptoms.size();i++)
		{
			if(res.size()==0)
				res.addAll(mapp.get(this.symptoms.get(i)));
			else
			{
				Set<String> temp=new HashSet<>();
				temp.addAll(mapp.get(this.symptoms.get(i)));
				res.retainAll(temp);
			}
				//res.retainAll(mapp.get(this.symptoms.get(i)));
		}
		System.out.println(res);
	}
}
