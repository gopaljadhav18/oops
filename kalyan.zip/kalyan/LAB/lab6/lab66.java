import pack6.M_Seva;
public class lab66
{
	public static void main(String[] args)
	{
		M_Seva ms=new M_Seva("fever","stomachpain","fatigue");
		ms.getDisease();
	}
}
