package pack5;
public class Arith
{
	int rp,ip;
	public Arith()
	{
		this.rp=0;
		this.ip=0;
	}
	public Arith(int rp,int ip)
	{
		this.rp=rp;
		this.ip=ip;
	}
	public void Add(Arith a1,Arith a2)
	{
		this.rp=a1.rp+a2.rp;
		this.ip=a1.ip+a2.ip;
		System.out.println(this.rp+"+"+"i"+this.ip);
	}
	public void Subtract(Arith a1,Arith a2)
	{
		this.rp=a1.rp-a2.rp;
		this.ip=a1.ip-a2.ip;
		System.out.println(this.rp+"+"+"i"+this.ip);
	}
}
