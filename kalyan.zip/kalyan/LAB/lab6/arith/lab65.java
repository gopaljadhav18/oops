import pack5.Arith;
public class lab65
{
	public static void main(String[] args)
	{
		Arith a1=new Arith(3,5);
		Arith a2=new Arith(6,4);
		Arith c=new Arith();
		c.Add(a1,a2);
		c.Subtract(a1,a2);
	}
}
