package pack2;
import pack2.Department;
public class ME implements Department
{
	public void display_subjects()
	{
		System.out.println("Strength of Materials");
		System.out.println("Linear Algebra");
		System.out.println("Digital Electronic Circuits");
		System.out.println("Analog Circuit");
		System.out.println("VLSI");
	}
}
