import pack2.Department;
import pack2.CSE;
import pack2.ECE;
import pack2.ME;
public class lab62
{
	public static void main(String[] args)
	{
		Department cse=new CSE();
		Department ece=new ECE();
		Department me=new ME();
		cse.display_subjects();
		ece.display_subjects();
		me.display_subjects();
	}
}
