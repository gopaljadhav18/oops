package pack2;
import pack2.Department;
public class CSE implements Department
{
	public void display_subjects()
	{
		System.out.println("Database Management System");
		System.out.println("Operating Systems");
		System.out.println("Discrete Mathematics");
		System.out.println("Linear Algebra");
		System.out.println("Data Analysis and Algorithms");
	}
}
