package pack2;
import pack2.Department;
public class ECE implements Department
{
	public void display_subjects()
	{
		System.out.println("Signals and Systems");
		System.out.println("Analog Electronic Circuits");
		System.out.println("Digital Electronic Circuits");
		System.out.println("Analog Circuit");
		System.out.println("VLSI");
	}
}
