import java.util.*;
class Car
{
	public String name;
	public double  mileage;
	public double speed;
	public String color;
	public double time=0;
	public double fuel=0;
	public Car(String nm,double mil,double spd,String col)
	{
		name=nm;
		mileage=mil;
		speed=spd;
		color=col;
	}
	public String getName()
	{
		return this.name;
	}
	public String getColor()
	{
		return this.color;
	}
	public double getMileage()
	{
		return mileage;
	}
	public double getSpeed()
	{
		return speed;
	}
	public void setTime(double dist)
	{
		this.time=dist/speed;
	}
	public void setFuel(double dist)
	{
		this.fuel=dist/mileage;
	}
	public double getTime()
	{
		return this.time;
	}
	public double getFuel()
	{
		return this.fuel;
	}
	public double getTotalValue()
	{
		double tm=this.time;
		double fl=this.fuel;
		return tm+fl;
	}
	public static void main(String[] args)
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter No.of Cars Details to Enter :");
		n=sc.nextInt();
		List<Car>l=new ArrayList<>();
		//Scanner sc=new Scanner(System.in);
		Scanner sct=new Scanner(System.in);
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Name of the Car: ");
			String name=sct.nextLine();
			System.out.println("Enter Speed of the Car: ");
			double speed=sc.nextDouble();
			System.out.println("Enter Mileage of the Car: ");
			double mil=sc.nextDouble();
			System.out.println("Enter Color of the Car: ");
			String col=sct.nextLine();
			Car obj=new Car(name,mil,speed,col);
			l.add(obj);
		}
		double tot=Double.MAX_VALUE;
		Car car=null;
		System.out.println("Enter Dist: ");
		double dist=sc.nextInt();
		for(Car obj: l)
		{
			obj.setTime(dist);
			obj.setFuel(dist);
			obj.getTotalValue();
			if(tot>obj.getTotalValue())
			{
				tot=obj.getTotalValue();
				car=obj;
			}
		}
		if(car!=null)
		{
			System.out.println(car.getName());
			System.out.printf("Time: %.2f\n",car.getTime());
			System.out.printf("Fuel: %.2f\n",car.getFuel());
			System.out.println(car.getColor());
		}
		
	}

}

