import java.util.*;
class TV
{
	public int channel;
	public int volume;
	public boolean on;
	public TV(int ch,int vol,boolean state)
	{
		channel=ch;
		vol=volume;
		on=state;
	}
	public boolean state()
	{
		return this.on;
	}
	public void setChannel(int ch)
	{
		this.channel=ch;
	}
	public void setVolume(int ch)
	{
		this.volume=ch;
	}
	public void channelUp()
	{
		this.channel+=1;
	}
	public void channelDown()
	{
		this.channel-=1;
	}
	public void volumeUp()
	{
		this.volume+=1;
	}
	public void volumeDown()
	{
		this.channel-=1;
	}
	public void turnOn()
	{
		on=true;
	}
	public void turnOff()
	{
		on=false;
	}
	public int Present_Channel()
	{
		return this.channel;
	}
	public int Present_Volume()
	{
		return this.volume;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int swth;
		TV obj1=new TV(0,0,false);
		System.out.print("Follow the following,to do Oprations\n1. Enter 1111 to turn on Tv\n2.Enter 0000 to turn off the Tv\n3. Enter 1 to set channel\n4. Enter 2 to set volume\n5. Enter 11 to channel up\n6. Enter 21 to volumeup\n7. Enter 10 to channel down \n8.Enter 20 to volume down \n9. Enter 111 to see present channel\n10. Enter 222 to see present volume\n11.Enter 1010 to know whether TV is ON or OFF\n");
		System.out.print("Enter Here to Continue: ");
		swth=sc.nextInt();
		while(swth!=-1)
		{
			switch(swth)
			{
				case 0000:
				{
					obj1.turnOff();
					break;
				}
				case 1111:
				{
					obj1.turnOn();
					break;
				}
				case 1:
				{
					System.out.print("Enter Channel Number: ");
					int ch=sc.nextInt();
					obj1.setChannel(ch);
					break;
				}
				case 2:
				{
					System.out.print("Enter Volume Number: ");
					int vl=sc.nextInt();
					obj1.setVolume(vl);
					break;
				}
				case 11:
				{
					obj1.channelUp();
					break;
				}
				case 21:
				{
					obj1.volumeUp();
					break;
				}
				case 10:
				{
					obj1.channelDown();
					break;
				}
				case 20:
				{
					obj1.volumeDown();
					break;
				}
				case 111:
				{
					System.out.println(obj1.Present_Channel());
					break;
				}
				case 222:
				{
					System.out.println(obj1.Present_Volume());
					break;
				}
				case 1010:
				{
					System.out.println(obj1.state());
					break;
				}
				default:
					System.out.print("Enter Valid Input");
			}
			System.out.print("Enter -1 to exit or any Oparation Command to continue: ");
			swth=sc.nextInt();
		}
		
	} 
}
