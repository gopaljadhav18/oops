import java.util.ArrayList;
import java.util.Scanner;
class vehicle{
    protected String company;
    protected String model;
    protected double mileage;
    protected double fuelcapacity;
    protected double displacement;
    public vehicle(String company,String model,double mileage,double fuelcapacity,double displacement){
        this.company=company;
        this.model=model;
        this.mileage=mileage;
        this.fuelcapacity=fuelcapacity;
        this.displacement=displacement;
    }
    public String getcompany(){
        return company;
    }
    public String getmodel(){
        return model;
    }
    public double getmileage(){
        return mileage;
    }
    public double fuelcapacity(){
        return fuelcapacity;
    }
    public double getdisplacement(){
        return displacement;
    }
}
class twowheeler extends vehicle{
    private String frontbrake;
    private String rearbrake;
    private String tyretype;
    private String headlamp;
    private String userreview;
    public twowheeler(String company,String model,double mileage,double fuelcapacity,double displacement, 
    String frontbrake,
   String rearbrake,String tyretype,String headlamp,String userreview ){
  super(company,model,mileage,fuelcapacity,displacement);
  this.frontbrake=frontbrake;
  this.rearbrake=rearbrake;
  this.tyretype=tyretype;
  this.headlamp=headlamp;
  this.userreview=userreview;
   }
}
class fourwheeler extends vehicle{
    private String airconditioner;
    private String airbags;
    private String powersteering;
    private String rainsensingwiper;
    public fourwheeler(String company,String model,double mileage,double fuelcapacity,double displacement,
     String airconditioner,String airbags, String powersteering,String rainsensingwiper){
        super(company,model,mileage,fuelcapacity,displacement);
        this.airconditioner=airconditioner;
        this.airbags=airbags;
        this.powersteering=powersteering;
        this.rainsensingwiper=rainsensingwiper;


     }
}
public class mileage {
    public static void main(String args[]){
        ArrayList<twowheeler> twowheeler=new ArrayList<>();
        ArrayList<fourwheeler> fourwheeler=new ArrayList<>();
        System.out.println("two wheeler");
        twowheeler[] wheeler;
        for(twowheeler wheeler:wheelers){
            System.out.println(wheeler.getcompany() + " " + wheeler.getmodel());
        }
        for(fourwheeler wheeler:wheelers){
           System.out.println(wheeler.getcompany() + " " + wheeler.getmodel()); 
        }
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nenter the two number of vehicle");
        int numtwowheeler=scanner.nextInt();
        ArrayList<twowheeler> selectedtwowheeler=new ArrayList<>();
         
        System.out.println("\nenter the four number of vehicle");
        int numfourwheeler=scanner.nextInt();
        ArrayList<fourwheeler> selectedfourwheeler=new ArrayList<>();
        System.out.println("\n comparing twowheeler");
        System.out.println("\n comparing fourwheeler");



    }
}
