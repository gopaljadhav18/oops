import java.util.Scanner;
class account{
    private String bankname;
    private String branchname;
    private String accountname;
    private String accountnumber;
    private Double balance;
    private String address;
    public account(String bankname,String branchname,String accountname,String accountnumber,Double initialbalance, String address){
       this.bankname=bankname;
       this.branchname=branchname;
       this.accountname=accountname;
       this.accountnumber=accountnumber;
       if(initialbalance>1000.0){
        this.balance=initialbalance;  
       }
       else
       {
        System.out.println("initial balance must be greater tha 1k");
        System.exit(1);
       }
       this.address=address;
    }
    public void credit(double amount){
        balance+=amount;
        System.out.println("amount credit " + amount);
        displaybalance();

    }
    public void debit(double amount){
        if(balance>=amount){
            balance-=amount;
            System.out.println("amount debited " + amount);
        }
        else
        {
            System.out.println("insuffient funds");
        }
        displaybalance();
    }
    public void displaybalance(){
        System.out.println("current balance" + balance);
    }
    public void exit(){
        System.out.println("exiting individual transaction...");
    }
}
public class bank{
    public static void main(String [] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("welcome to sbi");
        do{
            System.out.println("enter the branch name");
            String branchname=scanner.next();
             System.out.println("enter the account number");
            String accountnumber=scanner.next();
            account account1=new account("sbi",branchname,"accountholder",accountnumber,2000.0,"sample address");
            account account2=new account("niza",branchname,"accountholder",accountnumber,1000.0,"niza");
           // System.out.println("login successful" + account1.getbranchname() + "branch!");
            while(true){
                System.out.println("\n select a transaction");
                 System.out.println("1.credit");
                  System.out.println("2.debit");
                   System.out.println("3.display balance");
                    System.out.println("4.exit transation");
                    int choice=scanner.nextInt();
                    switch(choice){
                        case 1:
                        System.out.println("enter the amount");
                        double creditamount=scanner.nextDouble();
                        account1.credit(creditamount);
                        break;
                        case 2:
                        System.out.println("enter the debit");
                        double debitamount=scanner.nextDouble();
                        account1.debit(debitamount);
                        break;
                       case 3:
                       account1.displaybalance();
                       break;
                       case 4:
                       account1.exit();
                       break;
                       default:
                       System.out.println("invalid choice");
                    }
                    if(choice ==4)
                    break;

            }
            System.out.println("exit application");
        }
        while(!scanner.next().equalsIgnoreCase("yes"));
        System.out.println("exiting appication.thank you");
    }
}