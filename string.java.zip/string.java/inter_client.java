 import java.util.*;
 interface client{
    void input();
    void output();
 }
class inter_client implements client {
    String name; double sal;
    public void input()
    {
        Scanner r= new Scanner(System.in);
        System.out.println("enter username");
        name=r.nextLine();
        System.out.println("enter the salary");
        sal=r.nextDouble();
    }
    public void output()
    {
       System.out.println(name +" " + sal); 
    }
    public static void main(String args[]){
        client c= new  inter_client();
        c.input();
        c.output();
    }
}

