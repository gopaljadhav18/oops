import javax.swing.SpringLayout;
class A{
    public void show(){
        System.out.println("in a show");
    }
    public void config(){
        System.out.println("in A config");
    }
}
class B extends A{

}
public class riding {
    public static void main(String args[]){
        B obj=new B();
        obj.show();
        obj.config();
    }
}
