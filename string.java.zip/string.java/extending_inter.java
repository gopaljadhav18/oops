interface gill{
    void add();
}
interface raj extends gill{
    void sub();
}
class ankit implements gill{
    @Override
    public void add(){
        int a=10,b=20,c;
        c=a+b;
        System.out.println("addition " + c);
    }
    
    public void sub(){
        int a=10,b=12,c;
        c=a-b;
        System.out.println("substraction " + c);
    }
}
public class extending_inter {
    public static void main(String args[]){
   ankit r= new ankit();
   r.add();r.sub();
}
}
