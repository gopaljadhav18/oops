import java.util.Scanner;
abstract class emp{
    abstract double getamount();
}
class weeklyemployee extends emp{
    private int numberofweeks;
    private double totalamount;
    public weeklyemployee(int numberofweeks,double totalamount ){
        this.numberofweeks=numberofweeks;
        this.totalamount=totalamount;
    }
    double getamount(){
        return totalamount/numberofweeks;
    }
}
class hourlyemployee extends emp{
     private int numberofhours;
    private double totalamount;
    public hourlyemployee(int numberofhours,double totalamount ){
        this.numberofhours=numberofhours;
        this.totalamount=totalamount;
    }
    double getamount(){
        return totalamount/numberofhours;
    }
}
public class employee {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the number of weeks for weekly employee");
        int weeks=scanner.nextInt();
        System.out.println("enter the total amount  for weekly employee");
      double weeklyamount=scanner.nextDouble();
      weeklyemployee weeklyemployees=new weeklyemployee (weeks,weeklyamount);
      printamountpaid(weeklyemployees);
      System.out.println("enter the number of hours for houlyly employee");
        int hours=scanner.nextInt();
        System.out.println("enter the total amount  for hourlyly employee");
      double hourlyamount=scanner.nextDouble();
      hourlyemployee hourlyemployees=new hourlyemployee (hours,hourlyamount);
      printamountpaid(hourlyemployees);


    }
    private static void printamountpaid(emp emps){
        System.out.println("amount " + emps.getamount());
    }
    
}
