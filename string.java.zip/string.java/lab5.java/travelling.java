import java.util.Scanner;
interface fare{
    double getfare();
    String getamenities();
}
class bus implements fare{
    private double fare;
    private String amenities;
    public bus(double fare,String amenities){
        this.fare=fare;
        this.amenities=amenities;
    }
    public double getfare(){
        return fare;
    }
    public String getamenities(){
        return  amenities;
    }
}
class train implements fare{
    private double fare;
    private String amenities;
    public train(double fare,String amenities){
        this.fare=fare;
        this.amenities=amenities;
    }
    public double getfare(){
        return fare;
    }
    public String getamenities(){
        return  amenities;
    }
}
class flight implements fare{
    private double fare;
    private String amenities;
    public flight(double fare,String amenities){
        this.fare=fare;
        this.amenities=amenities;
    }
    public double getfare(){
        return fare;
    }
    public String getamenities(){
        return  amenities;
    }
}

public class travelling {
    public static void main(String args[]){
        Scanner scanner= new Scanner(System.in);
        System.out.println("\nenter the bus details");
        System.out.println("Fare");
        double busfare=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("amenities");
        String busamenities=scanner.nextLine();
        bus Bus=new bus(busfare,busamenities);
        printdetails(Bus);
        System.out.println("\nenter the train details");
        System.out.println("Fare");
        double trainfare=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("amenities");
        String trainamenities=scanner.nextLine();
        train Train=new train(trainfare,trainamenities);
        printdetails(Train);
        System.out.println("\nenter the flight details");
        System.out.println("Fare");
        double flightfare=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("amenities");
        String flightamenities=scanner.nextLine();
        flight Flight=new flight(flightfare,flightamenities);
        printdetails(Flight);

    }
    private static void  printdetails(fare Fare){
        System.out.println("fare " + Fare.getfare());
        System.out.println("amenities " + Fare.getamenities());

    }
    
}
