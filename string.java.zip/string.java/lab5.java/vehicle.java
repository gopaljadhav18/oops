import java.util.Scanner;
interface veh{
    String getcompany();
    String getmodel();
    String gettype();
    double getconsumption();
    void display();
}
class twowheeler implements veh{
    private String company;
    private String model;
    private String type;
    private double consumption;
    public twowheeler(String company,String model,String type,double consumption){
        this.company=company;
        this.model=model;
        this.type=type;
        this.consumption=consumption;
    }
    public String getcompany(){
        return company;
    }
    public String getmodel(){
        return model;
    }
    public String gettype(){
        return type;
    }
    public double getconsumption(){
        return consumption;
    }
    public void display(){
        System.out.println("comapnay " + getcompany());
        System.out.println("model " + getmodel());
        System.out.println("type " + gettype());
        System.out.println("consumption " + getconsumption());
    }
}
class fourwheeler implements veh{
    private String company;
    private String model;
    private String type;
    private double consumption;
    public fourwheeler(String company,String model,String type,double consumption){
        this.company=company;
        this.model=model;
        this.type=type;
        this.consumption=consumption;
    }
    public String getcompany(){
        return company;
    }
    public String getmodel(){
        return model;
    }
    public String gettype(){
        return type;
    }
    public double getconsumption(){
        return consumption;
    }
    public void display(){
        System.out.println("comapnay " + getcompany());
        System.out.println("model " + getmodel());
        System.out.println("type " + gettype());
        System.out.println("consumption " + getconsumption());
    }
}
public class vehicle {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the twowheeler details");
        System.out.println("company");
        String twowheelercompany=scanner.nextLine();
        System.out.println("model");
        String twowheelermodel=scanner.nextLine();
        System.out.println("type");
        String twowheelertype=scanner.nextLine();
        System.out.println("consumption");
        Double twowheelerconsumption=scanner.nextDouble();
        twowheeler twowheelers=new twowheeler(twowheelercompany,twowheelermodel,twowheelertype,twowheelerconsumption);
        twowheelers.display();
         System.out.println("enter the fourwheeler details");
        System.out.println("company");
        String fourwheelercompany=scanner.nextLine();
        System.out.println("model");
        String fourwheelermodel=scanner.nextLine();
        System.out.println("type");
        String fourwheelertype=scanner.nextLine();
        System.out.println("consumption");
        Double fourwheelerconsumption=scanner.nextDouble();
        fourwheeler fourwheelers=new fourwheeler(fourwheelercompany,fourwheelermodel,fourwheelertype,fourwheelerconsumption);
        fourwheelers.display();

    }
    
}
