import java.util.Scanner;
interface bank{
    void credit();
    void debit();
    void displaybalance();
    void personalloaneligibility();
    void homeloaneligibility();
    void vehicleloaneligiblity();
    
}
class SBI implements bank{
    public void credit(){
        System.out.println("credit in SBI");
    }
    public void debit(){
        System.out.println("debit in SBI");
    }
    public void displaybalance(){
        System.out.println("displaybalance in SBI");
    }
    public void personalloaneligibility(){
        int income;
        boolean govt;
         Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
        if(govt==true && income>5000)
        System.out.println("personalloaneligibility in SBI");
        else
        System.out.println("no personalloaneligibility in SBI");
    }
    public void homeloaneligibility(){
         int income;
        boolean govt;
        Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
      if(govt==true && income>5000)
        System.out.println("homeloaneligibility in SBI");
        else
        System.out.println("no home loaneligibility in SBI");
    }
    public void vehicleloaneligiblity(){
        int income;
        boolean govt;
         Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
      if(govt==true && income>5000)
        System.out.println("vehicleloaneligibility in SBI");
        else
        System.out.println("no vehicle loaneligibility in SBI");
        
    }
}
class HDFC implements bank{
    public void credit(){
        System.out.println("credit in HDFC");
    }
    public void debit(){
        System.out.println("debit in HDFC");
    }
    public void displaybalance(){
        System.out.println("display balance in HDFC");
    }
    public void personalloaneligibility(){
        int income;
        boolean govt;
         Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
        if(govt==true && income>5000)
        System.out.println("personalloaneligibility in SBI");
        else
        System.out.println("no personalloaneligibility in SBI");
        
    }
    public void homeloaneligibility(){
        
         int income;
        boolean govt;
        Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
      if(govt==true && income>5000)
        System.out.println("homeloaneligibility in SBI");
        else
        System.out.println("no home loaneligibility in SBI");
    }
    public void vehicleloaneligiblity(){
        int income;
        boolean govt;
         Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
      if(govt==true && income>5000)
        System.out.println("vehicleloaneligibility in SBI");
        else
        System.out.println("no vehicle loaneligibility in SBI");
        
    }
}
class DCB implements bank{
    public void credit(){
        System.out.println("credit in DCB");
    }
    public void debit(){
        System.out.println("debit in DCB");
    }
    public void displaybalance(){
        System.out.println("displaybalance in DCB");
    }
    public void personalloaneligibility(){
       int income;
        boolean govt;
         Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
        if(govt==true && income>5000)
        System.out.println("personalloaneligibility in SBI");
        else
        System.out.println("no personalloaneligibility in SBI");
    }
    public void homeloaneligibility(){
       
         int income;
        boolean govt;
        Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
      if(govt==true && income>5000)
        System.out.println("homeloaneligibility in SBI");
        else
        System.out.println("no home loaneligibility in SBI");
    }
    public void vehicleloaneligiblity(){
        int income;
        boolean govt;
         Scanner scanner=new Scanner(System.in);
        System.out.println("if he is govt employee");
         govt=scanner.nextBoolean();
        System.out.println("if his income ");
         income=scanner.nextInt();
      if(govt==true && income>5000)
        System.out.println("vehicleloaneligibility in SBI");
        else
        System.out.println("no vehicle loaneligibility in SBI");
    }
}
public class banks {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("select bank 1.SBI 2.HDFC 3.DCB");
        int choice= scanner.nextInt();
        bank selectbank;
        switch(choice){
            case 1:
            selectbank=new SBI();
            break;
            case 2:
            selectbank=new HDFC();
            break;
            case 3:
            selectbank=new DCB();
            break;
            default:
            System.out.println("invalid bank");
             return;
        }
        selectbank.credit();
        selectbank.debit();
        selectbank.displaybalance();
        selectbank.personalloaneligibility();
        selectbank.homeloaneligibility();
        selectbank.vehicleloaneligiblity();
    }
}
