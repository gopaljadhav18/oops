
import java.util.Scanner;
abstract class Shape{
    abstract double getarea();
    abstract double getvolume();
}
class square extends Shape{
    private double side;
    public square(double side){
        this.side=side;
    }
    double getarea(){
        return side*side;
    }
    double getvolume(){
        return 0;
    }
}
class circle extends Shape{
    private double radius;
    public circle(double radius){
        this.radius=radius;
    }
    double getarea(){
        return Math.PI*radius*radius;
    }
    double getvolume(){
        return 0;
    }
}
class cube extends Shape{
    private double side;
    public cube(double side){
        this.side=side;
    }
    double getarea(){
        return 6*side*side;
    }
    double getvolume(){
        return side*side*side;
    }
}
class sphere extends Shape{
    private double radius;
    public sphere(double radius){
        this.radius=radius;
    }
    double getarea(){
        return 4*Math.PI*radius*radius;
    }
    double getvolume(){
        return (4.0/3.0)*Math.PI*radius*radius*radius;
    }
}
public class area_vol {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the side of a square");
        double squareside=scanner.nextDouble();
        square squares= new square(squareside);
        System.out.println("enter the radius of a circle");
        double circleradius=scanner.nextDouble();
      circle circles= new circle(circleradius);
      System.out.println("enter the side of a cube");
        double cubeside=scanner.nextDouble();
        cube cubes= new cube(cubeside);
        System.out.println("enter the radius of a spheres");
        double sphereradius=scanner.nextDouble();
        sphere spheres= new sphere(sphereradius);
      printareaandvolume(squares);
      printareaandvolume(circles);
      printareaandvolume(cubes);
      printareaandvolume(spheres);

    }
    private static void printareaandvolume(Shape shape){
        System.out.println("area " + shape.getarea());
         System.out.println("volume " + shape.getvolume());


    }
}
