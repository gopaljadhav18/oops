 class demo{
    int a=10; String b="ankush";
    void show(){
        System.out.println(a+ " " +b);
    }
 }
public class object {
    public static void main (String args[]){
    demo r= new demo();
    r.show();
    
}
}
