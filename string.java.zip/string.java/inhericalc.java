class calc{
    public int add(int n1,int n2){
        return n1+n2;
    }
    public int sub(int n1,int n2){
        return n1-n2;
    }
    public int div(int n1,int n2){
        return n1/n2;
    }
    public int mul(int n1,int n2){
        return n1*n2;
    }
}
 public class inhericalc {
    public static void main(String args[]){
        calc obj =new calc();
        int r1=obj.add(1,2);
        int r2=obj.sub(7, 9);
        int r3=obj.div(8,4);
        int r4=obj.mul(8,4);
        System.out.println(r1 + " " + r2 + " " + r3 + " " + r4);
    }
}

