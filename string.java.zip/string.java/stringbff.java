public class stringbff {
     public static void main(String args[]){
        StringBuffer sb= new StringBuffer( "srinivas");
        System.out.println(sb.length());
        System.out.println(sb.capacity());
        sb.deleteCharAt(2);
        sb.insert(5,"java ");
        System.out.println(sb);
     }
}
