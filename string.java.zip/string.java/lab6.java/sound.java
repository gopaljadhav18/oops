package sounds;
import java.util.Scanner;
public interface dolby{
    void playdoly();
}
public class podcast implements dolby{
    public void playdolby(){
        System.out.println("playing doly sound");
    }
    public void playpodcast(){
        System.out.println("playing podcast sound");
    }
}
public class sound {
    public static void main(String args[]){
        Scanner scanner= new Scanner(System.in);
        System.out.println("choose  a sound type. 1.dolby 2.podcast");
        int choice = scanner.nextInt();
        switch(choice){
            case 1:
            dolby dolbysound =new podcast();
            dolbysound.playdolby();
            break;
        case 2:
        podcast podcastsound = new podcast();
        podcastsound.playpodcast();
        break;
        default:
        System.out.println("invalid choice ");
        }
    }
}
