package admission;
import java.util.Scanner;
public interface admissioninterface{
    boolean isadmissible(int mathsmarks,int physicsmarks,int chemistrymarks,int englishmarks);
}
public class engineergingadmission implements admissioninterface{
    public boolean isadmissible(int mathsmarks,int physicsmarks,int chemistrymarks,int englishmarks){
        return mathsmarks>=90 && physicsmarks>=95 && chemistrymarks>=70 && englishmarks>=80 &&
        calculatetotalpercentage(mathsmarks,physicsmarks,chemistrymarks,englishmarks)>=80;
    }
    private double calculatetotalpercentage(int mathsmarks,int physicsmarks,int chemistrymarks,int englishmarks){
        return(mathsmarks+physicsmarks+chemistrymarks+englishmarks)/4.0;
    }
}
public class admissionsystem {
    public static void main(String args[]){
        Scanner scanner= new Scanner(System.in);
        System.out.println("enter the deatils for admission");
        System.out.println("mathsmarks");
        int mathsmark=scanner.nextInt();
        System.out.println("physicssmarks");
        int physicsmark=scanner.nextInt();
        System.out.println("chemistrymarks");
        int chemistrymark=scanner.nextInt();
        System.out.println("englishmarks");
        int englishmark=scanner.nextInt();
        admissioninterface Admissionsystem=new engineeringadmission();
        if(Admissionsystem.isadmissible(mathsmarks,physicsmarks,chemistrymarks,englishmarks)){
            System.out.println("congratulation! you are eligible for admission");
        }
        else
        {
          System.out.println("sorry! you are not eligible for admission");  
        }
    }
    
}
