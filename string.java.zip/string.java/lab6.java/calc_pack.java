import java.util.Scanner;
import calculator.BasicCalculator;
  package calculator;
public interface Calculator{
    double add(double num1,double num2);
    double sub(double num1,double num2);
    double mul(double num1,double num2);
    double div(double num1,double num2);
}
   public class BasicCalculator implements Calculator{
    public double add(double num1,double num2){
        return num1+num2;
    }
 public double sub(double num1,double num2){
        return num1-num2;
    }
     public double mul(double num1,double num2){
        return num1*num2;
    }
     public double div(double num1,double num2){
        if(num2!=0){
            return num1/num2;
        }
        else{
    System.out.println("cannot divvde");
    return Double.NaN;
        }
    }
   }
public class calc_pack {
    public static void main(String[] args){
        Scanner scanner= new Scanner(System.in);
        BasicCalculator calculator= new BasicCalculator();   
        System.out.println("enter the first number");
        double num1=scanner.nextDouble();
        System.out.println("enter the second number");
        double num2=scanner.nextDouble();
        System.out.println("Sum: " + calculator.add(num1,num2));
        System.out.println("diff: " + calculator.sub(num1,num2));
        System.out.println("product: " + calculator.mul(num1,num2));
        System.out.println("div: " + calculator.div(num1,num2));

    }
    
}
