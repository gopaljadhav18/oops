class shape {
    void draw(){
        System.out.println("Cant say shape type");
    }  
}
class square extends shape {
    @Override
    void draw(){
        super.draw();
        System.out.println("square shape");
    }
}
class method_overriding {
    public static void main(String args[]){
        shape r= new square();
        r.draw();
    }
}
