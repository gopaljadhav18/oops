class hello{
     public static void main(String args[]){
        String name="srinivas";
        name=name + " kethavath";
        System.out.println("hello " + name);
        System.out.println(name);
        System.out.println(name==name);

     }
}