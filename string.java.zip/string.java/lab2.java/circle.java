import java.util.Scanner;
public class circle {
    private double radius;
    public circle(double radius){
        this.radius=radius;
    }
    public double getarea(){
        return Math.PI*radius*radius;
    }
    public double getperimeter(){
        return 2*Math.PI*radius;
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the radius of the circle");
        double radius=sc.nextDouble();
        circle c1=new circle(radius);
        double area=c1.getarea();
        System.out.println("area of the circle " + area);
        double perimeter=c1.getperimeter();
        System.out.println("perimeter of the circle " + perimeter);
    }
}
