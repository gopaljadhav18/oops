import java.util.Scanner;
public class dog {
    private String name;
    private String breed;
    private String color;
    private Double height;
    private String type;
  public dog(String name,String breed,String color,Double height,String type){
    this.name=name;
    this.breed=breed;
    this.color=color;
    this.height=height;
    this.type=type;
  }
  public String getname(){
    return name;
  }
    public String getbreed(){
        return breed;
    }
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter name");
        String username=scanner.nextLine();
        System.out.println("enter breed");
        String userbreed=scanner.nextLine();
        System.out.println("enter color");
        String usercolor=scanner.nextLine();
        System.out.println("enter height");
        Double userheight=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("enter type");
        String usertype=scanner.nextLine();
        dog mydog=new dog(username,userbreed,usercolor,userheight,usertype);
        System.out.println("name: " + mydog.getname());
        System.out.println("breed: " + mydog.getbreed());
        System.out.println("color: " + mydog.color);
        System.out.println("height: " + mydog.height + "ft");
        System.out.println("type: " + mydog.type);
    }
}
