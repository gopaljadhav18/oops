import java.util.Scanner;
 public class car{
    private String company;
    private double mileage;
    private double speed;
    private String color;

    public  car(String company,double mileage,double speed,String color){
        this.company=company;
        this.mileage=mileage;
        this.speed=speed;
        this.color=color;
    }
    public double getmileage(){
        return mileage;
    }
    public double getspeed(){
        return speed;
    }
    public static void main(String[] args){
        Scanner scanner= new Scanner(System.in);
        System.out.println("enter the company");
        String usercompany=scanner.nextLine();
        System.out.println("enter the mileage");
        double usermileage=scanner.nextDouble();
        scanner.nextLine();
        System.out.println("enter the speed");
        double userspeed=scanner.nextDouble();
         scanner.nextLine();
        System.out.println("enter the color");
        String usercolor=scanner.nextLine();
        car mycar= new car(usercompany,usermileage,userspeed,usercolor);
        System.out.println("company: " + mycar.company);
        System.out.println("mileage: " + mycar.getmileage());
        System.out.println("speed:  " + mycar.getspeed());
        System.out.println("color: "+  mycar.color);
                
    }
}
       

