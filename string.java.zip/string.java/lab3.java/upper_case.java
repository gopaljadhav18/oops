import java.util.Scanner;

public class upper_case {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the string");
        String userinput=scanner.nextLine();
        String uppercaseString=convertToUppercase(userinput);
        System.out.println("upper string" + uppercaseString);
        String lowercaseString=convertToLowercase(userinput);
        System.out.println("lower string" + lowercaseString);
    }
    private static String convertToUppercase(String original){
        return original.toUpperCase();
    }
    private static String convertToLowercase(String original){
        return original.toLowerCase();
    }

}
