
import java.util.Scanner;
public class StringEqualityApp {
    public static void main(String args[])
    {
Scanner scanner= new Scanner(System.in);
System.out.print("enter the first string");
String firstString=scanner.nextLine();
System.out.print("enter the second string");
String secondString=scanner.nextLine();
    if(firstString.equals(secondString))
    System.out.println("the string are equal");
    else
     System.out.println("the string are not equal");
    if(firstString.equalsIgnoreCase(secondString))
    System.out.println("the string are equal(case insensitive)");
    else
     System.out.println("the string are not equal(case insensitive)");
    
    }
}
