import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
class employee{
    String empid;
    String empname;
    int empage;
    String empgender;
    String empdesignation;
    double empsalary;
    String empaddress;
    public employee(String empid,String empname,int empage,String empgender,String empdesignation,double empsalary,String empaddress){
        this.empid=empid;
        this.empname=empname;
        this.empage=empage;
        this.empgender=empgender;
        this.empdesignation=empdesignation;
        this.empsalary=empsalary;
        this.empaddress=empaddress;

    }
}
public class emp_details {
    public static void main(String args[]){
        Map<String,employee> employeeMap=new HashMap<>();
        employeeMap.put("e101", new employee("e101","srinivas",30,"male","software",70000.09,"123 main st"));
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the employee id");
        String requiredemployeeid=scanner.nextLine();
        if(employeeMap.containsKey(requiredemployeeid)){
            employee requiredemployee=employeeMap.get(requiredemployeeid);
            System.out.println("employee id"+ requiredemployee.empid);
            System.out.println("employee name"+ requiredemployee.empname);
            System.out.println("employee age"+ requiredemployee.empage);
            System.out.println("employee gender"+ requiredemployee.empgender);
            System.out.println("employee designation"+ requiredemployee.empdesignation);
            System.out.println("employee salary"+ requiredemployee.empsalary);
            System.out.println("employee address"+ requiredemployee.empaddress);
        }

    }
    
}
