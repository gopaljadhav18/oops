
import java.util.Scanner;
public class StringCompareApp {
    public static void main( String args[])
    {
        Scanner scanner=new Scanner(System.in);
        System.out.print("enter the first string");
        String firstString=scanner.nextLine();
        System.out.print("enter the second string");
        String secondString= scanner.nextLine();
        int result=firstString.compareTo(secondString);
        if(result==0)
        System.out.println("both are equal");
        else if(result<0)
        System.out.println("the first string comes before the second string");
        else
        System.out.println("the first string comes after the second string");
    }
       
}
