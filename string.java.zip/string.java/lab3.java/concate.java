package lab2.java;
import java.util.Scanner;
class concate {
    public static void main(String args[])
    {
        Scanner scanner= new Scanner(System.in);
        System.out.print("enter the f.string");
        String str1= scanner.nextLine();
         System.out.print("enter the s.string");
        String str2= scanner.nextLine();
        String result=str1.concat(str2);
        System.out.println("concated string" + result);


    }
    
}
