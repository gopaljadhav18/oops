
import java.util.Scanner;
public class count_vowel_cons {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter a string");
        String inputstring=scanner.nextLine();
        int vowelcount=0;
        int conscount=0;
        int i;
        for(i=0;i<inputstring.length();i++){
            char currentchar=inputstring.charAt(i);
            if(currentchar=='a'||currentchar=='e'||currentchar=='i'||currentchar=='o'||currentchar=='u' && 
            currentchar=='A'||currentchar=='E'||currentchar=='I'||currentchar=='O'||currentchar=='U'){
                System.out.print(currentchar + " ");
                vowelcount++;
            }
                else
                {
                conscount++;
            }
            
        }
        System.out.println("\n number of vowels count " + vowelcount);
        System.out.println("\n number of consonent count " + conscount);

    }

}
