package TVRemotePackage;

public interface RemoteControl {
    void switchOn();

    void switchOff();

    void selectChannel(int channelNumber);
}
