package mseva;

public class mseva_operations implements mseva_methods
{
    public boolean ap(String d[])
    {
        String s[] = {"stomach ache","vomiting","low eye sight","muscle ache" ,"fever"};
        for ( String i : d )
        {
            for ( String a : s )
            {
                if ( i.equals(a) )
                {
                    return true;
                }
            }
        }
        return false;
    }
    public boolean a(String d[])
    {
        String s[] = {"stomach ache","vomiting","low eye sight","fever" ,"fatigue"};
        for ( String i : d )
        {
            for ( String a : s )
            {
                if ( i.equals(a) )
                {
                    return true;
                }
            }
        }
        return false;
    }
    public boolean bc(String d[])
    {
        String s[] = {"stomach ache","vomiting","low eye sight","skin allergy" ,"low bp"};
        for ( String i : d )
        {
            for ( String a : s )
            {
                if ( i.equals(a) )
                {
                    return true;
                }
            }
        }
        return false;
    }
    public boolean bp(String d[])
    {
        String s[] = {"stomach ache","vomiting","low eye sight","fever","fatigue"};
        for ( String i : d )
        {
            for ( String a : s )
            {
                if ( i.equals(a) )
                {
                    return true;
                }
            }
        }
        return false;
    }
}