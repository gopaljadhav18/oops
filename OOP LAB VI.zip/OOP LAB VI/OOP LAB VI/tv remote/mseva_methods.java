package mseva;

public interface mseva_methods
{
    boolean ap(String d[]);
    boolean a(String d[]);
    boolean bc(String d[]);
    boolean bp(String d[]);
}