import mseva.mseva_operations;
import java.util.*;

public class mseva_code
{
    public static void main(String args[])
    {
        mseva_operations m = new mseva_operations();
        Scanner sc = new Scanner(System.in);
        String s[] = new String[10];
        int i=0;
        while( true )
        {
            String st = sc.nextLine();
            s[i++] = st;
            if ( st.equals("stop") )
            {
                break;
            }
        }
        while ( i < 10 )
        {
            s[i++] = "empty";
        }
        for ( String str : s )
        {
            System.out.println(str + " ");
        }
        System.out.println();
        // (AP),  (A),  (BC), Pancreatic Cancer (PC)
        if ( m.ap(s) )
        {
            System.out.println("Acute pancreatitis");
        }
        if ( m.a(s) )
        {
            System.out.println("Appendicitis");
        }
        if ( m.bc(s) )
        {
            System.out.println("Bladder Cancer");
        }
        if ( m.bp(s) )
        {
            System.out.println("Pancreatic Cancer");
        }
    }
}