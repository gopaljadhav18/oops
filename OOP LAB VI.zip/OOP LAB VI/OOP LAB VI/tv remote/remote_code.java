import remote.remot_operations;
import java.util.*;

public class remote_code
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        remot_operations r = new remot_operations();
        boolean flag = true;
        int a;
        while ( flag )
        {
            System.out.println("Menu\n1.Switchon\n2.Starsports\n3.NGC\n4.Discovery\n5.Starmovies\n6.Switchoff");
            a = sc.nextInt();
            switch ( a )
            {
                case 1 :
                    r.switchon();
                    flag = false;
                    break;
            }
        }
        flag = true;
        while ( flag ) 
        {
            System.out.println("Menu\n1.Switchon\n2.Starsports\n3.NGC\n4.Discovery\n5.Starmovies\n6.Switchoff");
            a = sc.nextInt();
            switch ( a )
            {
                case 1 : 
                    System.out.println("TV is already On.");
                    break;
                case 2 :
                    r.starssports();
                    break;
                case 3 :
                    r.ngc();
                    break;
                case 4 :
                    r.discovery();
                    break;
                case 5 :
                    r.starmovies();
                    break;
                case 6 :
                    flag = false;
                    break;
            }
        }
    }
}