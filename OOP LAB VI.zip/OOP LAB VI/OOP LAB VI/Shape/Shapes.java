package Shape;

public interface Shapes {
    double calculateArea();

    double calculatePerimeter();
}
