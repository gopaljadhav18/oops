package ReservationCostPackage;

public class ReservationCalculator implements ReservationCost {

    @Override
    public double total_fare(Passenger[] passengers) {
        double totalFare = 0;

        for (Passenger passenger : passengers) {
            if (passenger instanceof Child) {
                // No fare for children
                // Additional logic for children if needed
            } else if (passenger instanceof Student) {
                // 30% discount for students
                totalFare += 0.7 * getActualFare();
            } else if (passenger instanceof SeniorCitizen) {
                // 50% discount for senior citizens
                totalFare += 0.5 * getActualFare();
            } else if (passenger instanceof Citizen) {
                // No discount for citizens
                totalFare += getActualFare();
            }
            // Additional logic for other types of passengers can be added here
        }

        return totalFare;
    }

    // Method to get the actual fare (can be modified as per your requirements)
    private double getActualFare() {
        // Replace this with your logic to calculate the actual fare
        return 100.0; // Placeholder value for demonstration
    }
}
