package ReservationCostPackage;

public class Student extends Passenger {

}
