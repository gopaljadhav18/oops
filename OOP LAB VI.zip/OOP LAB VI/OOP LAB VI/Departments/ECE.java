package Departments;

public class ECE implements Department {

    @Override
    public void displaySubjects() {
        System.out.println("Digital Electronic Circuits");
        System.out.println("Analog Electronic Circuits");
        System.out.println("Computer Organization and Architecture");
        System.out.println("Signals and Systems");
    }

}
