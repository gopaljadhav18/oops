import Admissions.EngineeringAdmission;

public class Admission {
    public static void main(String[] args) {
        EngineeringAdmission admissionProcessor = new EngineeringAdmission();

        // Example students with marks
        int student1Maths = 92;
        int student1Physics = 96;
        int student1Chemistry = 75;
        int student1English = 85;

        int student2Maths = 88;
        int student2Physics = 97;
        int student2Chemistry = 72;
        int student2English = 82;

        // Check eligibility for each student
        boolean isStudent1Eligible = admissionProcessor.checkEligibility(student1Maths, student1Physics,
                student1Chemistry, student1English);
        boolean isStudent2Eligible = admissionProcessor.checkEligibility(student2Maths, student2Physics,
                student2Chemistry, student2English);

        // List eligible students
        if (isStudent1Eligible) {
            System.out.println("Student 1 is eligible for engineering admission.");
        } else {
            System.out.println("Student 1 is not eligible for engineering admission.");
        }

        if (isStudent2Eligible) {
            System.out.println("Student 2 is eligible for engineering admission.");
        } else {
            System.out.println("Student 2 is not eligible for engineering admission.");
        }
    }
}
