/*
Create a package TV-Remote and include the interfaces and classes for the 
following case study and import the package to tune the channels as user desires.
Model a Television remote system with the following requirements. 
Total Buttons 6.
1- SWITCH ON
6- SWITCH OFF
2- STAR SPORTS CHANNEL
3- NGC CHANNEL
4- DISCOVERY CHANNEL
5- STARMOVIES CHANNEL
Selecting the buttons plays( print related channel Text) the channel as stated 
above. Once the TV is SWITCHED ON the Remote gets life by displaying 
message “Welcome to TATA SKY”. Until TV is SWITCHED OFF we can tune 
(change) the channels at our interest.  
*/

import TVRemotePackage.TVRemote;

public class TV {
    public static void main(String[] args) {
        TVRemote tvRemote = new TVRemote();

        // Turn on the TV
        tvRemote.switchOn();

        // Select channels
        tvRemote.selectChannel(1); // STAR SPORTS CHANNEL
        tvRemote.selectChannel(3); // DISCOVERY CHANNEL

        // Turn off the TV
        tvRemote.switchOff();
    }

}
