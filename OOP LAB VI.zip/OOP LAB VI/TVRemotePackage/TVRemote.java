package TVRemotePackage;

public class TVRemote implements RemoteControl {
    private boolean isOn;

    public TVRemote() {
        this.isOn = false;
    }

    @Override
    public void switchOn() {
        if (!isOn) {
            isOn = true;
            System.out.println("Welcome to TATA SKY");
        } else {
            System.out.println("TV is already ON.");
        }
    }

    @Override
    public void switchOff() {
        if (isOn) {
            isOn = false;
            System.out.println("TV is now OFF.");
        } else {
            System.out.println("TV is already OFF.");
        }
    }

    @Override
    public void selectChannel(int channelNumber) {
        if (isOn) {
            switch (channelNumber) {
                case 1:
                    System.out.println("Playing STAR SPORTS CHANNEL");
                    break;
                case 2:
                    System.out.println("Playing NGC CHANNEL");
                    break;
                case 3:
                    System.out.println("Playing DISCOVERY CHANNEL");
                    break;
                case 4:
                    System.out.println("Playing STARMOVIES CHANNEL");
                    break;
                default:
                    System.out.println("Invalid channel selection.");
            }
        } else {
            System.out.println("TV is OFF. Please switch it ON first.");
        }
    }
}
