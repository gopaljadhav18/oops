package Departments;

public class CSE implements Department {

    @Override
    public void displaySubjects() {
        System.out.println("Programming through Problem Solving in C");
        System.out.println("Object Oriented Programming in Java");
        System.out.println("Data Structures and Algorithms");
        System.out.println("Design and Analysis of Algorithms");
    }

}
