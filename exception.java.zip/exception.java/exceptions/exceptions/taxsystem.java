package audit;
public class taxsystem implements tax{
    double total_income;
    double total_expenditure;
    double taxpaid;
    double calculatedtax;
    public taxsystem(double total_income,double total_expenditure)
    {
        this.total_income=total_income;
        this.total_expenditure=total_expenditure;
    }
    public void taxchecker() 
    {
        calculatedtax=(0.1)*(total_income-total_expenditure);
        if(calculatedtax>taxpaid)
        {
            try{
            throw new TaxFraudException("you must pay");
            }
            catch(TaxFraudException e)
            {
                System.out.println(e);
            }
        }
        else
        {
            System.out.println("tax paid successfully");
        }
    }
    public void taxpaid(double taxpaid)
    {
        this.taxpaid=taxpaid;
        System.out.println("tax paid is"+taxpaid);
    }
    public void homeexpenditure(double amount)
    {
        total_expenditure+=amount;
    }
    public void healthexpenditure(double amount)
    {
        total_expenditure+=amount;
    }
    public void vehicleexpenditure(double amount)
    {
        total_expenditure+=amount;
    }
}
