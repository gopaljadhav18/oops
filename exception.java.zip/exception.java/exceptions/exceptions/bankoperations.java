
package bank_2;
public interface bankoperations {
    abstract boolean credentialscheck(String username,String password);
    abstract void credit(double amount);
    abstract void debit(double amount) throws InsufficientFundsException;
    abstract void displaybalance();
    abstract void exit();   
}
 
