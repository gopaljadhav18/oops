package audit;
public interface tax {
    abstract void taxchecker();
    abstract void taxpaid(double amount);
    abstract void homeexpenditure(double amount);
    abstract void healthexpenditure(double amount);
    abstract void vehicleexpenditure(double amount);
    
}
