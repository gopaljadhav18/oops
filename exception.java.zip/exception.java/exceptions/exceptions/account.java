package bank_2;
public class account implements bankoperations{
    String username;
    String password;
    double balance;
    public account(String username,String password,double balance)
    {
        this.username=username;
        this.password=password;
        this.balance=balance;
    }
    public boolean credentialscheck(String n,String p)
    {
        if(n.equals(username)&&p.equals(password))
        return true;
        else
        return false;
    }
    public void credit(double amount)
    {
        balance+=amount;
        displaybalance();
    }
    public void debit(double amount) throws InsufficientFundsException
    {
        if(amount>balance)
        throw new InsufficientFundsException("insuffecient balance");
        else
        balance-=amount;
        displaybalance();
    }
    public void displaybalance()
    {
        System.out.println("current balance="+balance);
    }
    public void exit()
    {
        System.out.println("exiting from the application");
        System.exit(0);
    }
}