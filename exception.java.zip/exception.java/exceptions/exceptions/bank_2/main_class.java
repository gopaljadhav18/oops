import bank_2.account;
import bank_2.bankoperations;
import bank_2.InsufficientFundsException;
import java.util.*;
public class main_class {
    public static void main(String args[])
    {
        account a=new account("sindhuja","sindhu",5000.0);
        Scanner sc=new Scanner(System.in);
        System.out.println("1.credit\n 2.debit\n 3.displaybalance\n 4.exit\n");
        if(a.credentialscheck("sindhuja","sindhu"))
        System.out.println("please welcome");
        else
        System.out.println("username and passwords are not match");
        while(true) {
        System.out.println("enter choice:");
        int choice=sc.nextInt();
        switch(choice)
        {
            case 1:a.credit(3000);
                   break;
                
            case 2:
            try{
                a.debit(5000);
                   
                
            }
            catch(InsufficientFundsException e)
            {
                System.out.println(e);
            }
            break;

            
            case 3:a.displaybalance();
                   break;
            case 4:a.exit();
                   break;
            default:
                   System.out.println("invalid option");
        }
    }
    }
    
}
