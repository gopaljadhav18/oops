package audit;
public class TaxFraudException extends Exception{
    public TaxFraudException(String message)
    {
        super(message);
    }
}