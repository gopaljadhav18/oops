public class lab7_4 {
    public static void main(String args[])
    {
        try{
            int result=20/0;
            System.out.println("result ="+result);
            String a=null;
            System.out.println("length of string is "+a.length());
            int []b={1,2,3};
            int val=b[5];
            System.out.println("value at 5th index is"+val);
        }
        catch(ArithmeticException e)
        {
            System.out.println(e);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }
        finally{
            System.out.println("execution completed");
        }
    }
    
}
