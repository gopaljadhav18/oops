import audit.tax;
import audit.TaxFraudException;
import audit.taxsystem;
public class main_class1 {
    public static void main(String args[])
    {
        taxsystem t=new taxsystem(20000,2000);
        t.taxpaid(30000);
        t.homeexpenditure(200);
        t.vehicleexpenditure(500);
        t.healthexpenditure(400);
        t.taxchecker();


    }
    
}
