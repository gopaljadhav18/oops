import java.util.*;
import java.lang.*;

class TrafficLight {
    public String currentSignal;

    public TrafficLight() {
        this.currentSignal = "red";
    }

    public synchronized void changeSignal(String newSignal) {
        this.currentSignal = newSignal;
        System.out.println("signal: " + currentSignal);
    }

}

class signalController implements Runnable {
    private final TrafficLight tl;

    public signalController(TrafficLight tl) {
        this.tl = tl;
    }

    public void run() {
        try {
            while (true) {
                Thread.sleep(10000); // 10 sec gap(1sec=1000 millisec)
                if (tl.currentSignal.equals("red"))
                    tl.changeSignal("yellow");
                else if (tl.currentSignal.equals("yellow"))
                    tl.changeSignal("Green");
                else
                    tl.changeSignal("red");
            }
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }
}

public class Light {
    public static void main(String[] args) {
        TrafficLight tl = new TrafficLight();
        signalController sc = new signalController(tl);
        Thread t1 = new Thread(sc);
        t1.start();
    }
}
