//passengers
import java.util.*;
import java.lang.*;
class ex5
{
    private static final int AC_capacity=2*70;
    private static final int sleep_capacity=2*70;
    public static void main(String args[])
    {
         Scanner s=new Scanner(System.in);
         try{
            System.out.println("Enet the no.of req berths: ");
            int numberths=s.nextInt();
            if(numberths>6)
            {
                throw new Exception("You may be an agent");
            }
            System.out.println("Enter the class (AC/Sleeper): ");
            String ticketclass=s.next();
            if(ticketclass.equalsIgnoreCase("AC")&&numberths>AC_capacity)
            {
                throw new Exception("You may be an agent");
            }
            if(ticketclass .equalsIgnoreCase("Sleeper")&&numberths>sleep_capacity)
            {
                throw new Exception("You may be an agent");

            }
            List<String>confirmedberths=allocatedberths(numberths,ticketclass);
            System.out.println("Confirmed Berths: "+confirmedberths);

         }
         catch(Exception e)
         {
            System.out.println(e.getMessage());
         }
         finally{
            s.close();
         }
         }
         private static List<String>allocatedberths(int numberths,String ticketclass)
         {
            Random random=new Random();
            List<String>allocatedberths=new ArrayList<>();
            for(int i=0;i<numberths;i++)
            {
                if(ticketclass.equalsIgnoreCase("AC"))
                {
                    if(random.nextBoolean())
                    {
                        allocatedberths.add("B1-"+(random.nextInt(2)+1));
                    }
                    else{
                        allocatedberths.add("B2-"+(random.nextInt(2)+1));
                    }
                }
                else if(ticketclass.equalsIgnoreCase("Sleeper"))
                {
                    if(random.nextBoolean())
                    {
                        allocatedberths.add("S1-"+random.nextInt(70)+1);
                    }
                    else
                    {
                        allocatedberths.add("S2-"+random.nextInt(70)+1);
                    }
                }
            }
            return allocatedberths;
         }
    }
