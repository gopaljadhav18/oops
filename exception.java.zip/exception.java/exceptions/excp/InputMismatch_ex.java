
import java.util.InputMismatchException;
import java.util.Scanner;
class InputMismatch_ex{
    public static void input()
    {
        Scanner s=new Scanner(System.in);
            System.out.println("enter number=");
            int n=s.nextInt();
            System.out.println("num="+n);
    }
    public static void main(String[]args)
    {
        try{
        input();
        }
        
        catch(InputMismatchException e)
        {
            System.out.println(e);//java.util.InputMismatchException
        }
    }
}

