public class MyThread extends Thread {
    public void run() {
        System.out.println("run method");
    }

    public static void main(String[] args) {
        MyThread m1 = new MyThread();
        Thread t1 = new Thread(m1);
        t1.start();
    }
}