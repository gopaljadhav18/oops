import java.util.InputMismatchException;
import java.util.*;
import java.lang.*;

interface func {
    public void taxPaid(double tax);

    public void homeExp(double amt);

    public void healthExp(double amt);

    public void vehicleExp(double amt);

    public void personalFamilyExp(double amt);

    public void miscellaneousExp(double amt);

    public void taxChecker(double taxPaid, double totalTax);
}

class Expenditure implements func {
    double homeEx, healthEx, vehicleEx, personalEx, miscellEx, taxpaid;

    public void taxPaid(double tax) {
        this.taxpaid = tax;
    }

    public void homeExp(double amt) {
        this.homeEx = amt;
    }

    public void healthExp(double amt) {
        this.healthEx = amt;
    }

    public void vehicleExp(double amt) {
        this.vehicleEx = amt;
    }

    public void personalFamilyExp(double amt) {
        this.personalEx = amt;
    }

    public void miscellaneousExp(double amt) {
        this.miscellEx = amt;
    }

    public double TaxCalculator(double taxPaid, double totalIncome) {
        double Allexpenditures = homeEx + healthEx + vehicleEx + personalEx + miscellEx;
        double calculatedTax = (0.1) * Math.abs((totalIncome - Allexpenditures));
        return calculatedTax;
    }

    public void taxChecker(double taxPaid, double totalTax) throws InputMismatchException {
        double calculatedTax = TaxCalculator(taxPaid, totalTax);
        if (taxPaid != calculatedTax)
            throw new InputMismatchException("fraud done! and he has to pay" + calculatedTax);
        else {
            System.out.println("no fraud");
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Expenditure e = new Expenditure();
        System.out.println(
                "enter home expenditure,health expenditure,vehicle expenditure,personalFamily expenditure,miscellaneous expenditure");
        e.homeEx = s.nextDouble();
        e.healthEx = s.nextDouble();
        e.vehicleEx = s.nextDouble();
        e.personalEx = s.nextDouble();
        e.miscellEx = s.nextDouble();
        System.out.println("enter taxPaid,totalIncome=");
        double taxPaid = s.nextDouble();
        double totalIncome = s.nextDouble();

        e.taxPaid(taxPaid);

        e.homeExp(e.homeEx);

        e.healthExp(e.healthEx);

        e.vehicleExp(e.vehicleEx);

        e.personalFamilyExp(e.personalEx);

        e.miscellaneousExp(e.miscellEx);
        try {
            e.taxChecker(taxPaid, totalIncome);
        } catch (InputMismatchException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
