import java.util.Scanner;
interface bankoperation{
    void credentialscheck(String username,String password);
    void credit(double amount);
    void debit(double amount) throws insufficientbalanceException;
    void displaybalance();
    void exit();
}
class insufficientbalanceException extends Exception{
    insufficientbalanceException(String message){
        super(message);
    }
}
class bankaccount implements bankoperation{
    private String username;
    private  String password;
    private double balance;
    bankaccount(String username,String password,double initialbalance){
        this.username=username;
        this.password=password;
        this.balance=initialbalance;
    }

public void credentialscheck(String enterusername,String enterpassword){
    if(!username.equals(enterusername)||!password.equals(enterpassword)){
        System.out.println("username and password mismatch");
    }
}
public void credit(double amount){
    balance+=amount;
    System.out.println("amount credited" + amount);
}
public void debit(double amount) throws insufficientbalanceException{
    if(amount>balance)
    throw new insufficientbalanceException("debit amount exceed availabe balance");
    balance-=amount;
    System.out.println("amount debit " + amount);
}
public void displaybalance(){
    System.out.println("current balnce" + balance);
   
}
public void exit(){
    System.out.println("thank you!");
    System.exit(0);
}
}
public class bank {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter username");
        String username=scanner.nextLine();
         System.out.println("enter password");
        String password=scanner.nextLine();
        System.out.println("enter initial balance");
        double initialbalance=scanner.nextDouble();
        bankaccount useraccount=new bankaccount(username,password,initialbalance);
        while(true){
            System.out.println("choose an operation");
            System.out.println("1.credit");
            System.out.println("2.debit");
            System.out.println("3.display");
            System.out.println("4.exit");
       int choice =scanner.nextInt();
       switch(choice){
          case 1:
          System.out.println("enter the credit amount");
          double creditamount=scanner.nextDouble();
          useraccount.credit(creditamount);
          break;
          case 2:
           System.out.println("enter the debit amount");
            double debitamount=scanner.nextDouble();
            try{
                useraccount.debit(debitamount);
            }
            catch(insufficientbalanceException e){
                System.out.println(e.getMessage());
            }
            break;
            case 3:
            useraccount.displaybalance();
            break;
            case 4:
            useraccount.exit();
            break;
            default:
            System.out.println("invalid choice");
       }
        }

    }
    
}
