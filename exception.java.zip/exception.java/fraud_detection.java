
import java.util.Scanner;
interface taxaudit{
    double  taxchecker(double totalincome);
    double taxpaid(double taxpaid);
    double home(double home);
    double  health(double health);
    double  vehicle(double vehicle );
    double  personal(double personal);
    double  miscellaneous(double miscellaneous);
}
class taxauditimp implements taxaudit{
    private double totalincome;
    private double taxpaid;
    private double home;
    private double health;
    private double vehicle;
    private double personal;
    private double miscellaneous;
    public taxauditimp(double totalincome,double taxpaid,double home, double health, double vehicle,double personal, double miscellaneous){
        this.totalincome=totalincome;
        this.taxpaid=taxpaid;
        this.home=home;
        this.health=health;
        this.vehicle=vehicle;
        this.personal=personal;
        this.miscellaneous=miscellaneous;
    }
public double taxchecker(double totalincome){
    return totalincome*0.10;
}
public double taxpaid(double taxpaid){
    return taxpaid;
}
public double home(double home){
    return home;
}
public double health(double health){
    return health;
}
public double vehicle(double vehicle){
    return vehicle;
}
public double personal(double personal){
    return personal;
}
public double miscellaneous(double miscellaneous){
    return miscellaneous;
}
  public void calculatetax(){
    double totalexpenditure= totalincome+taxpaid+home+health+vehicle+personal+miscellaneous;
    double expectedtax=taxchecker(totalincome);
    if(totalexpenditure>expectedtax){
        double fraudamount=totalexpenditure-expectedtax;
        throw new RuntimeException("fraud detetction" + fraudamount);
    }
    else{
    double remainingtax=expectedtax-totalexpenditure+taxpaid;
    System.out.println("no fraud detection " + remainingtax);
  }    
}   
   
}
public class fraud_detection{
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the total income");
        double totalincome=scanner.nextDouble();
        System.out.println("enter the tax paid");
        double taxpaid=scanner.nextDouble();
        System.out.println("enter home");
        double home=scanner.nextDouble();
        System.out.println("enter the health");
        double health=scanner.nextDouble();
        System.out.println("enter the vehicle");
        double vehicle=scanner.nextDouble();
        System.out.println("enter thepersonal");
        double personal=scanner.nextDouble();
        System.out.println("enter the miscellaneous");
        double miscellaneous=scanner.nextDouble();
        taxauditimp taxaudits= new taxauditimp(totalincome,taxpaid,home,health,vehicle,personal,miscellaneous);
        try{
            taxaudits.calculatetax();
        }
        catch(RuntimeException e){
            System.out.println(e.getMessage());
        }
    }
}
