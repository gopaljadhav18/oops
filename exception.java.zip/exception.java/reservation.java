import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class reservation {
    private static int availableACbirth=2*70;
    private static availablesleeperbirth=2*70;
    public static void main(String args[]){
        try{
            Scanner scanner=new scanner(System.in);
            System.out.println("enter the number of berth");
            int numberth=scanner.nextInt();
            if(numberth>6)
            {
                throw newException("you may be an urgent");
            }
            System.out.println("enter the A/C class");
            String preferredclass=scanner.nextLine();
            if(!(preferredclass.equals("a/c") || preferredclass.equals("sleeper"))){

                throw new exception("you may be an urgent");
            }
            allocateanddisplayberth(preferredclass,numberth);
        }
        catch(Exception e){
            System.out.println("Book denied " + e.getmessage());
        }
    }
   private static void allocateanddisplayberth(String preferredclass,int numberth){
    System.out.println("confirmed berth:");
    for(i=1;i<=numberth;i++){
        String berth=allocateberth(preferredclass);
        System.out.println(berth + " ");
    }
    System.out.println();
    updateavailableberth(preferredclass,numberth);
   }

}
