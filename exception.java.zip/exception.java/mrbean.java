import java.io.IOException;
import java.util.Scanner;
public class mrbean{
    public static void main(String args[]){
        Scanner scanner= new Scanner(System.in);
        try{
            System.out.println("enter a number");
            int numerator=scanner.nextInt();
            System.out.println("enter another number");
            int denominator=scanner.nextInt();
            int result=dividenumber(numerator,denominator);
            System.out.println("result of div" + result);
            String nullstring=null;
            int [] array={1,2,3};
            System.out.println("enter an index of an array");
            int index=scanner.nextInt();
            accessarrayelement(array,index);
            simulateIOException();


        }
        catch(ArithmeticException e){
            System.out.println("arithemetic exception " + e.getMessage());
        }
         catch(NullPointerException e){
            System.out.println("nullpointer exception " + e.getMessage());
        }
         catch(ArrayIndexOutOfBoundsException e){
            System.out.println("arrayindexoutofbound exception " + e.getMessage());
        }
        catch(IOException e){
            System.out.println("IOException " + e.getMessage());
        }
        finally{
            System.out.println("cleanup the resource with block");
        }

    }
    private static int dividenumber(int numerator,int denominator){
        return numerator/denominator;
    }
    private static void printstringlength(String str){
      System.out.println("length of the string" + str.length());
    }
    private static void accessarrayelement(int [] array,int index){
        System.out.println("value at index"+ index + ". " + array[index]);
    }
    private static void simulateIOException() throws IOException {
        throw new IOException("simulated ioexception occured");  

    }


}