import java.util.InputMismatchException;
import java.util.Scanner;

public class numeric {
    public static void main(String args[]){
        try{
        double userinput=getinput();
        System.out.println("user entered " + userinput);
    }
    catch(InputMismatchException e){
        System.out.println("invalid input.please enter a numeric value");
    }
}
   private static  double getinput(){
    Scanner scanner=new Scanner(System.in);
    System.out.println("enter  a numeric value");
    double input=scanner.nextDouble();
    return input;
   }
}
